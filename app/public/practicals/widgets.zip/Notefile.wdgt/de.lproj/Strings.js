// German (Deutsch) by Jennifer Brehm

var translation = [];
translation['xx'] = 'de';

translation['Notefile requires OS X 10.5.8 or later and a Mac with an Intel processor.'] = 'Notefile benötigt Mac OS X 10.5.8 oder später.';

translation['No notes'] = 'Keine Notizen';
translation['1 note'] = '1 Notiz';
translation['%@ notes'] = '%@ Notizen';

translation['No Results'] = 'Keine Treffer';

translation['today'] = 'heute';
translation['tomorrow'] = 'morgen';
translation['yesterday'] = 'gestern';
translation['a moment ago'] = 'Vor einem Moment';
translation['a minute ago'] = 'Vor einer Minute';
translation['%@ minutes ago'] = 'Vor %@ Minuten';
translation['an hour ago'] = 'Vor einer Stunde';
translation['%@ hours ago'] = 'Vor %@ Stunden';
translation['a day ago'] = 'Vor einem Tag';
translation['%@ days ago'] = 'Vor %@ Tagen';

translation['Settings'] = 'Einstellungen';
translation['Add'] = 'Hinzufügen';
translation['Delete'] = 'Löschen';

translation['Syncing with iCloud…'] = 'iCloud synchronisieren …';
translation['Syncing with Junecloud…'] = 'Junecloud synchronisieren …';
translation['Couldn’t connect'] = 'Keine Verbindung';
translation['Synced %@'] = 'Synchr. %@';

translation['New version!'] = 'Neue Version!';
translation['A new version of Notefile is available! Click here to download it.'] = 'Eine neuere Version von Notefile ist erhältlich! Klicken Sie hier um sie zu laden.';

translation['General'] = 'Allgemein';
translation['Sync'] = 'Sync';
translation['Donate'] = 'Spenden';
translation['Help'] = 'Hilfe';

translation['Sign In'] = 'Anmelden';
translation['Register'] = 'Registrieren';
translation['Done'] = 'Fertig';
translation['Log Out'] = 'Abmelden';

translation['Text Size:'] = 'Textgröße:';

translation['Donate'] = 'Spenden';
translation['Please consider a donation'] = 'Bitte ziehen Sie eine Spende in Betracht';
translation['This widget is free, but it took a lot of work to create it. Please consider a small donation to help support Notefile!'] = 'Das Widget ist kostenlos aber es hat viel Arbeit gekostet. Bitte denken Sie über eine kleine Spende nach, um Notefile zu unterstützen!';
translation['Check this box if you have donated.'] = 'Ich habe bereits gespendet';
translation['Thank you for your donation! Your support allows us to keep making Notefile the best note keeping widget possible.'] = 'Danke für Ihre Spende! Ihre Unterstützung erlaubt es uns Notefile immer weiter zu verbessern.';

translation['Email Address:'] = 'E-Mail-Adresse:';
translation['Password:'] = 'Kennwort:';
translation['Confirm Password:'] = 'Kennwort bestätigen:';
translation['Your Name:'] = 'Ihr Name:';
translation['Optional'] = 'Optional';
translation['I agree to the <a href="http://junecloud.com/sync/legal/terms.html" onclick="return openSite(this.href)">Terms of Service</a>'] = 'Ich stimme den <a href="http://junecloud.com/sync/legal/terms.html" onclick="return openSite(this.href)">Dienstbedingungen</a> zu';

translation['Syncing with iCloud'] = 'Synchronisierung mit iCloud';
translation['Syncing with Junecloud'] = 'Synchronisierung mit Junecloud';
translation['Switch to iCloud'] = 'Zu iCloud wechseln';
translation['Switch to Junecloud'] = 'Zu Junecloud wechseln';
translation['If you need to change your settings, open System Preferences and click iCloud.'] = 'Falls Sie ihre Einstellungen ändern möchten, öffnen Sie Systemeinstellungen und klicken Sie auf iCloud.';
translation['Sign in to your Junecloud account to sync with any Mac, iPhone, iPad, iPod touch, or web browser. Data will be synced securely through junecloud.com.'] = 'Melden Sie sich bei Ihrem Junecloud-Account an, um mit Mac, iPhone, iPad, iPod touch oder Browser verschlüsselt über junecloud.com zu synchronisieren.';
translation['You are currently signed in as %@'] = 'Sie sind angemeldet als %@';
translation['Forgot your password?'] = 'Kennwort vergessen?';
translation['Log in successful.'] = 'Anmeldung erfolgreich.';
translation['You have been logged out.'] = 'Sie wurden abgemeldet.';

translation['Please enter your email address.'] = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
translation['Please enter your password.'] = 'Bitte geben Sie Ihr Kennwort ein.';
translation['Both password fields must match.'] = 'Beide Kennwortfelder müssen übereinstimmen.';
translation['Your email address or password is incorrect.'] = 'Ihre E-Mail-Adresse oder Ihr Kennwort ist falsch.';
translation['You must agree to the Terms of Service to continue.'] = 'Zum Fortfahren müssen Sie den Dienstbedingungen zustimmen.';