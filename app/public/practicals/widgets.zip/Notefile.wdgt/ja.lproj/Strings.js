// Japanese (日本語) by Nobtaka Nukui and Justin McPeak

var translation = [];
translation['xx'] = 'ja';

translation['Notefile requires OS X 10.5.8 or later and a Mac with an Intel processor.'] = 'NotefileはMac OS X 10.5.8以上が必要です';

translation['No notes'] = 'ノートがありません';
translation['1 note'] = '1つのノート';
translation['%@ notes'] = '%@枚のノート';

translation['No Results'] = '結果なし';

translation['today'] = '今日';
translation['tomorrow'] = '明日';
translation['yesterday'] = '昨日';
translation['a moment ago'] = '少し前';
translation['a minute ago'] = '1分前';
translation['%@ minutes ago'] = '%@分前';
translation['an hour ago'] = '1時間前';
translation['%@ hours ago'] = '%@時間前';
translation['a day ago'] = '1日前';
translation['%@ days ago'] = '%@日前';

translation['Settings'] = '設定';
translation['Add'] = '追加';
translation['Delete'] = '削除';

translation['Syncing with iCloud…'] = 'iCloudに同期中・・・';
translation['Syncing with Junecloud…'] = 'Junecloudに同期中・・・';
translation['Couldn’t connect'] = '接続できません';
translation['Synced %@'] = '最終更新日 %@';

translation['New version!'] = '新バージョン!';
translation['A new version of Notefile is available! Click here to download it.'] = '新しいバーションの Notefile が入手できます！クリックしてダウンロードする。';

translation['General'] = '一般';
translation['Sync'] = '同期';
translation['Donate'] = '寄付';
translation['Help'] = 'ヘルプ';

translation['Sign In'] = 'サインイン';
translation['Register'] = '登録';
translation['Done'] = '完了';
translation['Log Out'] = 'ログアウト';

translation['Text Size:'] = 'テキストサイズ：';

translation['Donate'] = '寄付';
translation['Please consider a donation'] = '寄付についてご検討いただけませんか。';
translation['This widget is free, but it took a lot of work to create it. Please consider a small donation to help support Notefile!'] = 'このウィジェットは無料ですが、このWidgetを作成する為に膨大な作業が必要でした。今後もより良い物の製作を続けるために少しのの寄付をご検討ください。';
translation['Check this box if you have donated.'] = '寄付していただけるならば、こちらのボックスをクリックしてください。';
translation['Thank you for your donation! Your support allows us to keep making Notefile the best note keeping widget possible.'] = 'ご寄付をして頂きありがとうございます。あなたのサポートにより、今後もより良い製品を提供し続けることができます。';

translation['Email Address:'] = '電子メール:';
translation['Password:'] = 'パスワード:';
translation['Confirm Password:'] = 'パスワード確認:';
translation['Your Name:'] = '名前:';
translation['Optional'] = '任意';
translation['I agree to the <a href="http://junecloud.com/sync/legal/terms.html" onclick="return openSite(this.href)">Terms of Service</a>'] = '<a href="http://junecloud.com/sync/legal/terms.html" onclick="return openSite(this.href)">使用許諾契約</a>に同意します。';

translation['Syncing with iCloud'] = 'iCloudと同期中';
translation['Syncing with Junecloud'] = 'Junecloudと同期中';
translation['Switch to iCloud'] = 'iCloudに変更';
translation['Switch to Junecloud'] = 'iCloudと同期中';
translation['If you need to change your settings, open System Preferences and click iCloud.'] = '設定を変更する場合は、システム環境設定を開きiCloudをクリックしてください。';
translation['Sign in to your Junecloud account to sync with any Mac, iPhone, iPad, iPod touch, or web browser. Data will be synced securely through junecloud.com.'] = 'Mac、iPhone、iPad、iPod touch、どのブラウザでも配送項目の同期に対応しています。Junecloudアカウントにサインインすると、データをjunecloud.com経由で安全に同期します。';
translation['You are currently signed in as %@'] = '%@でサインインされています。';
translation['Forgot your password?'] = 'パスワードを忘れましたか？';
translation['Log in successful.'] = 'ログイン成功。';
translation['You have been logged out.'] = 'ログアウトされました。';

translation['Please enter your email address.'] = '電子メールを入力してください。';
translation['Please enter your password.'] = 'パスワードを入力してください。';
translation['Both password fields must match.'] = 'パスワード欄は、一致する必要があります。';
translation['Your email address or password is incorrect.'] = 'メールアドレスまたは、パスワードに間違いがあります。';
translation['You must agree to the Terms of Service to continue.'] = '続けるには、使用許諾契約に同意していただく必要がございます。';