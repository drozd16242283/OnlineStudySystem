var appId = 'com.junecloud.widget.notefile';
var installedVersion;
var readableVersion;
var syncVersion = 5.1;
var timeZone = new Date().getTimezoneOffset();

var dismissDays = 30; // number of days to dismiss version checking
var lastVersion = 0; // the last version installed
var currentVersion; // the most recent version available
var downloadUrl = 'http://junecloud.com/software/mac/notefile-widget.html';

var currentSide = 'front';
var currentView = 'note';
var nextSide = '';
var nextView = '';

var doneButton;
var signInButton;
var registerButton;
var logOutButton;
var iCloudButton;
var junecloudButton;
var donateButton;

var currentNote;
var noteCount;
var saveTimer;
var keysDown = [];
var selectedNote;

var dashboardActive = true;
var scrollTimer;
var searchTimer;

var textSize = false;

// create an object to handle sync and version check requests

var sync = {};
sync.sync = true;
sync.req = [];
sync.reqCount = 0;
sync.reqComplete = 0;
sync.loadPage = loadPage;
sync.client = '';
sync.code = '';
sync.password = false;
sync.updated = 0;
sync.force = true;
sync.success;
sync.failures = 0;
sync.retry = false;
sync.first = 0;
var syncQueue = [];

var iCloud = {};
iCloud.uuid = '';
iCloud.updated = 0;

var forceJunecloud = false;

function $ (id) {
	return document.getElementById(id);
}

function setup () {

	if (typeof Notefile == 'undefined' || typeof JSON == 'undefined') {
		document.body.className = 'unsupported';
		$('unsupported').innerHTML = translate('Notefile requires OS X 10.5.8 or later and a Mac with an Intel processor.');
		return;
	}

	if (window.widget) {

		// load settings

		// Not currently used
		// lastVersion = (widget.preferenceForKey('lastversion')) ? 
		//	parseFloat(widget.preferenceForKey('lastversion')) : 0;

		interval = (widget.preferenceForKey('update')) ? 
			parseInt(widget.preferenceForKey('update'),10) : 60;

		sync.client = (widget.preferenceForKey(widget.identifier+'-syncclient')) ? 
			widget.preferenceForKey(widget.identifier+'-syncclient') : '';
		// if (sync.client) sync.code = getPassword('junecloud.com',appId);
		sync.email = (widget.preferenceForKey('syncemail')) ? 
			widget.preferenceForKey('syncemail') : '';		
		if (sync.email) sync.password = (getPassword('junecloud.com',sync.email)) ? true : false;
		sync.updated = (widget.preferenceForKey('syncupdated')) ? 
			parseInt(widget.preferenceForKey('syncupdated'),10) : 0;
		sync.offset = (widget.preferenceForKey('syncoffset')) ? 
			parseFloat(widget.preferenceForKey('syncoffset')) : 0;
		syncQueue = (widget.preferenceForKey('syncqueue') && typeof JSON.parse == 'function') ? 
			JSON.parse(widget.preferenceForKey('syncqueue')) : [];

		iCloud.uuid = (widget.preferenceForKey('iclouduuid')) ? 
			widget.preferenceForKey('iclouduuid') : '';

		textSize = 12;
		if (widget.preferenceForKey('size')) {
			if (widget.preferenceForKey('size') === true) {
				textSize = 13;
			} else textSize = parseInt(widget.preferenceForKey('size'));
		}
		$('size').value = textSize;
		selectSize(textSize,false);

	}

	// set up the resize handles

	$('resizer-front').addEventListener('mousedown',startResize,true);
	$('resizer-back').addEventListener('mousedown',startResize,true);

	// adjust AppleScrollArea to call didScroll(), since using onscroll doesn't work reliably

	AppleScrollArea.prototype.mousewheelScroll = function (event) {
		didScroll();
		var deltaScroll = event.wheelDelta / 120 * this.singlepressScrollPixels;
		this.verticalScrollTo(this.content.scrollTop - deltaScroll);
		event.stopPropagation();
		event.preventDefault();
	}

	// set up the scroll bar

	setUpScrollBar();
	scrollArea = new AppleScrollArea($('scroll'),scrollBar);
	scrollBar.setAutohide(true);
	scrollArea.singlepressScrollPixels = (webKitVersion() > 534) ? 20 : 5;

	// set up empty search, plus the add and info buttons
	
	$('no-results').innerText = translate('No Results');
	$('add').innerText = translate('Add');
	$('info').innerText = translate('Settings');

	// set up the tabs

	$('general-tab').innerText = translate('General');
	$('sync-tab').innerText = translate('Sync');
	$('donate-tab').innerText = translate('Donate');
	$('signin-segment').innerText = translate('Sign In');
	$('register-segment').innerText = translate('Register');

	// set up the info view

	$('sizelabel').innerHTML = translate('Text Size:');
	$('junecloud').title = 'Copyright © 2011-2012 Junecloud LLC.';
	$('helplink').innerText = translate('Help');

	$('syncemaillabel').innerText = translate('Email Address:');
	$('syncpasswordlabel').innerText = translate('Password:');
	$('syncconfirmlabel').innerText = translate('Confirm Password:');
	$('syncnamelabel').innerText = translate('Your Name:');
	$('syncname').placeholder = translate('Optional');
	$('synctermslabel').innerHTML = translate('I agree to the <a href="http://junecloud.com/sync/legal/terms.html" onclick="return openSite(this.href)">Terms of Service</a>');
	$('sync-info').innerText = translate('Sign in to your Junecloud account to sync with any Mac, iPhone, iPad, iPod touch, or web browser. Data will be synced securely through junecloud.com.');
	$('forgot').innerHTML = '<a href="https://junecloud.com/sync/?cmd=reset" onclick="return openSite(this.href)">'+translate('Forgot your password?')+'</a>';

	// create buttons

	createButtons();

	if (window.widget) {
		size = savedSize();
		setMinMax(currentView);
		setSize(size.width,size.height,true,false);
		setMaximized(size);

		getCurrentVersion();
		widget.setPreferenceForKey(installedVersion,'lastversion');
	}

	// load the notes

	$('content').onclick = contentClicked;
	$('list').onmouseover = function(){ this.className = 'mouse' };
	$('list').onmouseout = function(){ this.className = 'keyboard' };

	if (window.widget) currentNote = widget.preferenceForKey(widget.identifier+'-current');
	if (currentNote) {
		noteCount = getNoteArray().length;
		showNoteWithId(currentNote);
		setTimeout(showScrollBar,1000);
	} else showList(false,false);

	checkVersion(7,false);
	startSync();

	if (window.widget) {
		widget.ondragend = function () {

			scrollArea.removeScrollbar(scrollBar);
			scrollBar.remove();
			setUpScrollBar();
			scrollArea.addScrollbar(scrollBar);
			setMinMax(currentView);

			doneButton.remove();
			signInButton.remove();
			registerButton.remove();
			logOutButton.remove();
			iCloudButton.remove();
			junecloudButton.remove();
			donateButton.remove();
			createButtons();

		};
		widget.onhide = function () {
			dashboardActive = false;
			if (currentNote) saveNote();
			keysDown = [];
		};
		widget.onshow = function () {
			if (!dashboardActive) { // prevent calling this on initial load
				dashboardActive = true;
				showScrollBar();
				var currentZone = new Date().getTimezoneOffset();
				if (timeZone != currentZone && Notefile) {
					timeZone = currentZone;
					Notefile.localeOrTimeChanged();
				}
				startSync();
			}
		};
		widget.onremove = function () {
			saveNote();
			// We have to do this asynchronously or it never gets a chance to run
			widget.system('/usr/bin/osascript -e "tell application id \\\"com.junecloud.Notefile-Helper\\\" to quit"',null);
			widget.setPreferenceForKey(null,widget.identifier+'-current');
			widget.setPreferenceForKey(null,widget.identifier+'-width');
			widget.setPreferenceForKey(null,widget.identifier+'-height');
			widget.setPreferenceForKey(null,widget.identifier+'-syncclient');
		};
	}

}

function createButtons () {
	doneButton = new AppleGlassButton($('done-button'),translate('Done'),function(){saveSettings(true)});
	signInButton = new AppleGlassButton($('signin-button'),translate('Sign In'),saveSync);
	registerButton = new AppleGlassButton($('register-button'),translate('Register'),saveSync);
	logOutButton = new AppleGlassButton($('logout-button'),translate('Log Out'),function(){logOut(true)});
	iCloudButton = new AppleGlassButton($('icloud-button'),translate('Switch to iCloud'),function(){logOut(true)});
	junecloudButton = new AppleGlassButton($('junecloud-button'),translate('Switch to Junecloud'),switchToJunecloud);
	donateButton = new AppleGlassButton($('donate-button'),translate('Donate'),openDonate);
}

function setUpScrollBar () {
	scrollBar = new AppleVerticalScrollbar($('scrollbar'));
	scrollBar.setSize(8);
	scrollBar.setTrackStart('Images/Scroll/spacer.png',6);
	scrollBar.setTrackMiddle('Images/Scroll/spacer.png');
	scrollBar.setTrackEnd('Images/Scroll/spacer.png',6);
	if (window.devicePixelRatio > 1) {
		scrollBar.setThumbStart('Images/Scroll/thumb-top@2x.png',6);
		scrollBar.setThumbMiddle('Images/Scroll/thumb-middle@2x.png');
		scrollBar.setThumbEnd('Images/Scroll/thumb-bottom@2x.png',6);	
	} else {
		scrollBar.setThumbStart('Images/Scroll/thumb-top.png',6);
		scrollBar.setThumbMiddle('Images/Scroll/thumb-middle.png');
		scrollBar.setThumbEnd('Images/Scroll/thumb-bottom.png',6);
	}
}

function showScrollBar () {
	clearTimeout(scrollTimer);
	$('scrollbar').className = 'visible';
	scrollTimer = setTimeout(function(){ $('scrollbar').className = ''; },300);
}

function didScroll () {
	showScrollBar();
	updateDivider();
}

function getUUID () {
	return Notefile.getUUID();
}

function getPassword (from,extra) {
	var result = Notefile.getPassword(from,extra);
	if (result == null) result = '';
	return result;
}

function newObject (element,id,classname) {
	var object = document.createElement(element);
	if (id) object.setAttribute('id',id);
	object.className = classname;
	if (element == 'a') object.href = '#';
	return object;
}

function openSite (url) {
	if (window.widget) {
		widget.openURL(url);
		return false;
	}
	return true;
}

function activeUse () {
	// If Dashboard is open and the computer has been used in the past 3 minutes, it's active
	var result = false;
	if (dashboardActive) {
		var idleTime = Notefile.getIdleTime();
		if (idleTime < 180) result = true;
	}
	return result;
}


// status bar


function showMessage (message) {
	$('message').innerHTML = message;
}

function updatedText (text,timeStamp) {
	var updatedArray = Notefile.updatedText(timeStamp);
	if (updatedArray) {
		timeString = translateFormat(updatedArray[0],updatedArray[1]);
		if (text) timeString = translateFormat(text,timeString);
	}
	return timeString;
}

function updateStatus () {
	var message = '';
	if (currentNote || !syncEnabled()) {
		if (noteCount == 0) {
			message = translate('No notes');
		} else if (noteCount == 1) {
			message = translate('1 note');
		} else message = translateFormat('%@ notes',noteCount);
		var thisStamp = widget.preferenceForKey(currentNote+'-date');
		if (thisStamp) message += ' • '+updatedText(null,thisStamp);
	} else {
		if (sync.success !== false && sync.updated) {
			var updateStamp = sync.updated + sync.offset;
			message = updatedText('Synced %@',updateStamp);
		} else message = translate('Couldn’t connect');
	}
	showMessage(message);
}

function statusClicked (usedKeyboard) {
	if (currentNote) {
		saveNote();
		var willShowList = showList(false,usedKeyboard);
		if (!willShowList) startSyncNow();
	} else startSyncNow();
}


// search


function toggleSearch () {
	if ($('search-bar').className == 'active') {
		hideSearch();
	} else showSearch();
	setTimeout(refreshScrollArea,100);
}

function showSearch () {
	$('search-bar').className = 'active';
	$('search').focus();
}

function hideSearch () {
	$('search-bar').className = '';
	$('search').blur();
	$('search').value = '';
	updateSearch();
}

function updateSearch () {
	clearTimeout(searchTimer);
	searchTimer = setTimeout(function(){ refreshList(false) },100);
}


// mess with strings and html


function textToTitle (string) {
	string = trim(string);
	string = string.replace(/(<br[^>]*>|\r\n|\r|\n).*/g,'');
	return string;
}

function textToHTML (string) {
	string = htmlEntities(string);
	string = string.replace(/(\r\n|\r|\n)/g,'<br/>');
	string = string.replace(/(\t|\s{2,})/g,'<span style="white-space:pre">$1</span>');
	return string;
}

function htmlToText (string) {
	string = string.replace(/(\r|\n)/g,'');
	string = trim(string);
	string = string.replace(/<div[^>]*>(.*?)(<br[^>]*>)?<\/div[^>]*>(\n+)?/g,'$1\n');
	string = string.replace(/<br[^>]*>/g,'\n');
	string = string.replace(/&nbsp;/g,' ');
	string = string.replace(/<[^>]*>/g,'');
	return removeHtmlEntities(string);
}


// display various views


function getNoteArray () {
	var noteList = (window.widget && widget.preferenceForKey('notes')) ? widget.preferenceForKey('notes') : '';
	var noteArray = (noteList) ? noteList.split(';') : [];
	var searchText = trim($('search').value);
	if (searchText) {
		searchText = searchText.replace(/\s+/i,' ').toLowerCase();
		searchArray = searchText.split(' ');
		var foundArray = [];
		for (var i in noteArray) {
			var id = noteArray[i];
			var text = (widget.preferenceForKey(id+'-text')) ? widget.preferenceForKey(id+'-text').toLowerCase() : '';
			var show = true;				
			for (var x in searchArray) {
				if (!text.match(searchArray[x])) {
					show = false;
					break;
				}
			}
			if (show) foundArray.push(id);
		}
		noteArray = foundArray;
	}
	return noteArray;
}

function showList (animate,usedKeyboard) {
	var willShowList = false;
	if (currentNote && $(currentNote)) {
		var thisNote = currentNote;
		if (usedKeyboard) {
			selectNote(thisNote,true);
		} else {
			selectedNote = false;
			$(thisNote).className += ' highlighted';
			setTimeout(function(){
				var noteObject = $(thisNote);
				if (noteObject) noteObject.className = 'item';
			},200);
		}
	}
	setCurrentNote(null);
	refreshList(animate);
	if (noteCount) {
		switchFront('list');
		willShowList = true;
	} else showNoteWithId();
	updateStatus();
	return willShowList;
}

function refreshList (animate) {

	var noteArray = getNoteArray();
	var thisCount = 0;

	// Get the current list and delete any items that aren't in the new list
	var childIds = [];
	for (var i in $('list').childNodes) childIds.push($('list').childNodes[i].id);
	var listNodes = [];
	for (var i in childIds) {
		var id = childIds[i];
		if (id && id != 'search-bar' && id != 'please-donate') {
			var index = noteArray.indexOf(id);
			if (index == -1) {
				deleteRowId(id,false,animate);
			} else listNodes.push(id);
		}
	}

	for (var i in noteArray) {
		var id = noteArray[i];
		if (id) {

			var text = (widget.preferenceForKey(id+'-text')) ? textToTitle(widget.preferenceForKey(id+'-text')) : '';
			var date = (widget.preferenceForKey(id+'-date')) ? updatedText(null,widget.preferenceForKey(id+'-date')) : '';

			if (listNodes[i] == id) {
				
				$(id).childNodes[2].textContent = date;
				$(id).childNodes[3].textContent = text;

			} else {

				// If this item is already in the list, we need to delete it now so the id isn't duplicated
				if ($(id)) {
					deleteRowId(id,false,animate);
					var index = listNodes.indexOf(id);
					if (index != -1) listNodes.splice(index,1);
				}

				var itemObj = newObject('div',id,'item');
				itemObj.onmouseover = function(){ 
						selectNote(this.id,false);
						clearTimeout($(this.id).timer);
					};
				itemObj.onmouseout = function(){
						if (selectedNote == this.id) selectedNote = false;
						if (this.className.indexOf('confirming') != -1) {
							var thisId = this.id;
							$(this.id).timer = setTimeout(function(){
								var thisObject = $(thisId);
								if (thisObject) thisObject.className = thisObject.className.replace(' confirming','');
							},1000);
						}
					};
				itemObj.onclick = showNote;
		
				var deleteObj = newObject('div',false,'delete');
				deleteObj.parent = itemObj;
				deleteObj.innerText = translate('Delete');
				deleteObj.onclick = confirmDelete;
				itemObj.appendChild(deleteObj);
				
				var confirmObj = newObject('div',false,'confirm');
				confirmObj.parent = itemObj;
				confirmObj.innerText = translate('Delete');
				confirmObj.onclick = deleteNote;
				itemObj.appendChild(confirmObj);
			
				var dateObj = newObject('div',false,'date');
				dateObj.innerText = date;
				itemObj.appendChild(dateObj);
	
				itemObj.appendChild(document.createTextNode(text));

				// Add the new item
				itemObj.className = (animate) ? 'item adding' : 'item';
				if ($(listNodes[i])) {
					$('list').insertBefore(itemObj,$(listNodes[i]));
				} else if ($('please-donate')) {
					$('list').insertBefore(itemObj,$('please-donate'));
				} else {
					$('list').appendChild(itemObj);
				}
				if (animate) animateRowId(id);
				listNodes.splice(i,0,id);

			}

			thisCount++;

		}
	}

	var searchText = trim($('search').value);
	var emptySearch = (!thisCount && searchText) ? true : false;
	$('no-results').style.display = (emptySearch) ? 'block' : 'none';

	if (!searchText) noteCount = thisCount;

	if (getDonated() + 1 < installedVersion && !emptySearch) {
		if (!$('please-donate')) {
			var itemObj = newObject('div','please-donate','item donate');
			itemObj.onclick = function(){ showInfo('donate'); };
			itemObj.innerHTML = translate('Please consider a donation');
			$('list').appendChild(itemObj);
		}
	} else {
		if ($('please-donate')) $('list').removeChild($('please-donate'));
	}

	setTimeout(refreshScrollArea,650);

}

function deleteRowId (id,confirming,animated) {
	if ($(id)) {
		if (animated) {
			var newId = id+'-old';
			$(id).id = newId;
			$(newId).className = (confirming) ? 'item confirming deleted' : 'item deleted';
			setTimeout(function(){
				if ($(newId)) $('list').removeChild($(newId));
			},650);
		} else $('list').removeChild($(id));
	}
}

function animateRowId (id) {
	setTimeout(function(){ $(id).className = 'item' },50);
}

function showNote () {
	showNoteWithId(this.id);
}

function showNoteWithId (id) {
	if (!trim($('search').value)) hideSearch(false);
	if (id) {
		if (window.widget) $('content').innerHTML = (widget.preferenceForKey(id+'-text')) ? 
			textToHTML(widget.preferenceForKey(id+'-text')) : '';
		setCurrentNote(id);
	} else {
		$('content').innerHTML = '';
		setCurrentNote(getUUID());
	}
	updateStatus();
	focusContent();
	switchFront('note');
}

function selectNote (nextNote,highlight) {

	if (selectedNote && $(selectedNote) && $(selectedNote).className.indexOf('highlighted') != -1) 
		$(selectedNote).className = 'item';
	if (highlight) $(nextNote).className += ' highlighted';
	selectedNote = nextNote;

	if (highlight) {
		var position = $(nextNote).offsetTop - 13;
		if (position < $('scroll').scrollTop) {
			scrollArea.verticalScrollTo(position);
		} else if (position + $(nextNote).offsetHeight > $('scroll').scrollTop + scrollArea.viewHeight) {
			scrollArea.verticalScrollTo(position + 13 + $(nextNote).offsetHeight - scrollArea.viewHeight);
		}
	}

}

function setCurrentNote (id) {
	currentNote = id;
	if (window.widget) widget.setPreferenceForKey(id,widget.identifier+'-current');
}

function confirmDelete (e) {
	if (this.parent.id) {
		var parent = $(this.parent.id);
		parent.className = (parent.className == 'item') ? 'item confirming' : 'item';
	}
	e.stopPropagation();
}

function deleteNote (e) {
	e.stopPropagation();
	var id = this.parent.id;
	if (id) {
		var thisNote = $(id);
		deleteRowId(id,true,true);
		refreshScrollArea();
		deleteNoteWithId(id);
		syncNote(id,'delete',getUnixTime()-sync.offset);
	}
}

function deleteNoteWithId (id) {
	if (window.widget) {
		widget.setPreferenceForKey(null,id+'-text');
		widget.setPreferenceForKey(null,id+'-date');
		widget.setPreferenceForKey(null,id+'-modified');
		updateList(id,false);
	}
	if (!noteCount) showNoteWithId();
}

function arrayFromList (list) {
	if (!list) return [];
	return list.split(';');
}

function listFromArray (array) {
	if (!array) return '';
	return array.join(';').replace(/(^;+|;+$)/g,'');
}

function showInfo (view) {
	$('syncemail').value = sync.email;
	if (sync.email) $('syncpassword').value = getPassword('junecloud.com',sync.email);
	setDonated(true);
	$('version').innerText = 'Notefile '+readableVersion;
	switchToView('back',view);
}


// edit and save notes


function contentClicked (e) {
	e.stopPropagation();
}

function focusContent () {
	if ($('content').innerHTML) {
		var range = document.createRange();
		range.selectNodeContents($('content'));
		var selection = window.getSelection();
		selection.removeAllRanges();
		selection.addRange(range);
		selection.collapseToEnd();
	} else $('content').focus();
}

function keyDown (event) {

	var key = event.keyCode;
	if (key == 16 || key == 91 || key == 93) { // shift, left command, right command
		trackKey(key,true);
	} else if (currentSide == 'front') {
		if (commandDown()) {

			if (key == 90) { // z
				if (shiftDown()) {
					document.execCommand('Redo');
				} else document.execCommand('Undo');
				event.preventDefault();
			} else if (key == 78) { // n
				if (currentNote) saveNote();
				showNoteWithId();
				event.preventDefault();
			} else if (key == 13) { // return or enter
				statusClicked(true);
				event.preventDefault();
			} else if (key == 70 && currentView == 'list') { // f
				toggleSearch();
			}
			// Unfortunately command-left/right doesn't get passed to keyDown
			/* else if (key == 37 || key == 39) {
				var selection = window.getSelection();
				var range = selection.getRangeAt(0);	
				alert(range.startContainer+' '+range.startOffset+' '+range.endContainer+' '+range.endOffset);
				event.preventDefault();
			} */

		} else if (currentView == 'note') {

			if (key == 9) {
				document.execCommand('InsertHTML',false,'<span style="white-space:pre">\t</span>');
				event.preventDefault();
			}

		} else if (currentView == 'list') {

			if (key == 38) { // up
				arrowKey(false);
				event.preventDefault();
			} else if (key == 40) { // down
				arrowKey(true);
				event.preventDefault();
			} else if (key == 13 && selectedNote) { // return or enter
				showNoteWithId(selectedNote);
				event.preventDefault();
			}

		}
	}
	startSaveTimer();
	return true;

}

function keyUp (event) {
	var key = event.keyCode;
	if (key == 16 || key == 91 || key == 93) {
		trackKey(key,false);
		event.preventDefault();
	}
	refreshScrollArea();
	return true;
}

function trackKey (key,down) {
	var keyIndex = keysDown.indexOf(key);
	if (keyIndex == -1) { // not found
		if (down) keysDown.push(key);
	} else { // found
		if (!down) keysDown.splice(keyIndex,1);
	}
}

function commandDown () {
	return (keysDown.indexOf(91) != -1 || keysDown.indexOf(93) != -1) ? true : false;
}

function shiftDown () {
	return (keysDown.indexOf(16) != -1) ? true : false;
}

function arrowKey (down) {
	$('list').className = 'keyboard';
	var noteArray = getNoteArray();
	var nextNote;
	if (selectedNote) {
		var noteIndex = noteArray.indexOf(selectedNote);		
		if (noteIndex != -1) {
			if (down) {
				nextNote = (noteIndex == noteArray.length-1) ? selectedNote : noteArray[noteIndex+1];
			} else nextNote = (noteIndex == 0) ? selectedNote : noteArray[noteIndex-1];
		}
	}
	if (!nextNote) nextNote = (down) ? noteArray[0] : noteArray[noteArray.length-1];	
	if (nextNote) selectNote(nextNote,true);
}

function startSaveTimer () {
	if (saveTimer != null) clearTimeout(saveTimer);
	saveTimer = setTimeout(saveNote,60000);
}

function handlePaste (event) {
	refreshScrollArea();
	startSaveTimer();
	return true;
}

function saveNote () {

	if (saveTimer != null) clearTimeout(saveTimer);

	var text = htmlToText($('content').innerHTML);
	var id = currentNote;

	if (id && window.widget && text != widget.preferenceForKey(id+'-text')) {

		var hasText = (trim(text)) ? true : false;
		if (hasText) {
			var now = getUnixTime();
			widget.setPreferenceForKey(text,id+'-text');
			widget.setPreferenceForKey(now,id+'-date');
			widget.setPreferenceForKey(now,id+'-modified');
			syncNote(id,'add',0);
		} else {
			widget.setPreferenceForKey(null,id+'-text');
			widget.setPreferenceForKey(null,id+'-date');
			widget.setPreferenceForKey(null,id+'-modified');
			syncNote(id,'delete',getUnixTime()-sync.offset);
		}
		updateList(id,hasText);

	}

}

function updateList (id,keep) {
	var noteArray = arrayFromList(widget.preferenceForKey('notes'));

	for (var i in noteArray) {
		if (id == noteArray[i]) {
			noteArray.splice(i,1);
			break;
		}
	}
	if (keep) noteArray.unshift(id);
	noteArray.sort(sortByDate);
	noteCount = noteArray.length;
	noteList = listFromArray(noteArray);
	
	widget.setPreferenceForKey(noteList,'notes');
}

function sortByDate (a,b) {
	var aDate = (widget.preferenceForKey(a+'-date')) ? widget.preferenceForKey(a+'-date') : '';
	var bDate = (widget.preferenceForKey(b+'-date')) ? widget.preferenceForKey(b+'-date') : '';
	return (bDate - aDate);
}


// settings


function saveSettings (finish) {
	textSize = $('size').value;
	if (window.widget) widget.setPreferenceForKey(parseInt(textSize),'size');
	if (finish) {
		forceJunecloud = false;
		// If the last sync failed, and they cleared the email field, log them out
		if (!sync.success && sync.email && !$('syncemail').value) logOut(false);
		var side = 'list';
		if (currentNote) {
			if (!noteCount || trim(htmlToText($('content').innerHTML))) {
				side = 'note';
			} else setCurrentNote(null);
		}
		switchToView('front',side);
	}
}

function selectSize (value,userSelected) {
	value = parseInt(value);
	if (value && !isNaN(value)) $('size-text').innerText = value;
	document.body.className = 'textsize'+value;
}


// donations


function setDonated (getValue) {

	var value = false;
	if (getValue) {
		if (getDonated() + 1 >= installedVersion) value = true;
	} else {
		if ($('alreadydonated').checked) value = true;
	}
	if (value == true) {
		$('alreadydonated').checked = true;
		widget.setPreferenceForKey(installedVersion,'donated');
		$('donate-info').innerText = translate('Thank you for your donation! Your support allows us to keep making Notefile the best note keeping widget possible.');
	} else {
		$('alreadydonated').checked = false;
		widget.setPreferenceForKey(-1,'donated');
		$('donate-info').innerText = translate('This widget is free, but it took a lot of work to create it. Please consider a small donation to help support Notefile!');
	}
	$('alreadydonatedlabel').innerText = translate('Check this box if you have donated.');

	if (!getValue) refreshList(false);

}

function getDonated () {
	var donatedVersion = 0;
	if (window.widget) donatedVersion = (widget.preferenceForKey('donated')) ? widget.preferenceForKey('donated') : -1;
	return donatedVersion;
}

function openDonate () {
	openSite('http://junecloud.com/software/donate/');
}


// version checking


function getCurrentVersion () {

	var request = new XMLHttpRequest();
	request.open('GET','Info.plist',false);
	request.send();

	var nodes = request.responseXML.getElementsByTagName('dict')[0].childNodes;
	var nodeLength = nodes.length;
	for (var i = 0; i < nodeLength; i++) {
		if (nodes[i].nodeType == 1 && nodes[i].tagName.toLowerCase() == 'key') {
			if (nodes[i].firstChild.data == 'CFBundleShortVersionString') {
				readableVersion = nodes[i+2].firstChild.data;
			} else if (nodes[i].firstChild.data == 'CFBundleVersion') {
				var result = nodes[i+2].firstChild.data;
				result = result.replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/,'$1.$2$3');
				installedVersion = currentVersion = parseFloat(result);				
			}
		} 
	} 

}

function checkVersion (days,skipDismissed) {

	var lastVersionCheck = (widget.preferenceForKey('lastversioncheck')) ? 
		widget.preferenceForKey('lastversioncheck') : 0;
	var dismissedUpdate = (widget.preferenceForKey('dismissedupdate')) ? 
		widget.preferenceForKey('dismissedupdate') : 0;
	var currentTime = (new Date()).getTime();

	if (skipDismissed || !dismissedUpdate || dismissedUpdate + (86400000 * dismissDays) < currentTime) {
		if (lastVersionCheck + (86400000 * days) < currentTime) {
			checkVersionNow();
		} else {
			currentVersion = (widget.preferenceForKey('currentversion')) ? 
				parseFloat(widget.preferenceForKey('currentversion')) : installedVersion;
			if (currentVersion > installedVersion) showUpdateBadge();
		}
	}

}

function checkVersionNow () {
	sync.loadPage('https://junecloud.com/software/mac/version.php',getVersion,'id='+appId,false);
}

function getVersion () {

	var currentTime = (new Date()).getTime();
	widget.setPreferenceForKey(currentTime,'lastversioncheck');

	if (this.status == 200 && this.responseXML) {
		for (var child = this.responseXML.firstChild; child != null; child = child.nextSibling) {
			if (child.nodeName == 'versionstatus') {
				var itemlist = child;
				for (var item = itemlist.firstChild; item != null; item = item.nextSibling) {
					if (item.nodeName == 'version') {
						currentVersion = parseFloat(item.getAttribute('value'));
						widget.setPreferenceForKey(currentVersion,'currentversion');
					} else if (item.nodeName == 'download') {
						downloadUrl = item.getAttribute('value');
					}
				}
				break;
			}
		}
	}

	if (currentVersion > installedVersion) showUpdateBadge();

	this.reqComplete++;
	return;

}

function showUpdateBadge () {
	$('getupdate').href = downloadUrl;
	$('getupdate').innerHTML = translate('New version!');
	$('getupdate').title = translate('A new version of Notefile is available! Click here to download it.');
	$('updatebox').className = 'available';
}

function dismissUpdate () {
	var now = new Date();
	if (window.widget) widget.setPreferenceForKey(now.getTime(),'dismissedupdate');
	$('updatebox').className = '';
}


// syncing


function iCloudEnabled () {
	return Notefile.iCloudEnabled();
}

function switchToJunecloud () {
	forceJunecloud = true;
	$('sync-info').innerText = translate('Sign in to your Junecloud account to sync with any Mac, iPhone, iPad, iPod touch, or web browser. Data will be synced securely through junecloud.com.');
	setSync('login');
}

function startSyncNow () {
	sync.force = true;
	startSync();
}

function changedSyncEmail () {
	if ($('cmd').value == 'login') $('syncpassword').value = 
		($('syncemail').value) ? getPassword('junecloud.com',$('syncemail').value) : '';
}

function setSync (cmd) {

	$('cmd').value = cmd;

	$('icloud-button').style.display = '';
	if (sync.success && sync.email) {
		$('login-type').innerText = translate('Syncing with Junecloud');
		$('login-info').innerText = translateFormat('You are currently signed in as %@',sync.email);
		if (iCloudEnabled()) $('icloud-button').style.display = 'block';
		selectTab('sync signedin');
	} else if (!forceJunecloud && !syncEnabled() && iCloudEnabled()) {
		$('login-type').innerText = translate('Syncing with iCloud');
		$('login-info').innerText = translate('If you need to change your settings, open System Preferences and click iCloud.');
		selectTab('sync icloud');
	} else {
		if (cmd == 'register') {
			$('syncemail').value = '';
			$('syncpassword').value = '';
			$('syncconfirm').value = '';
			$('syncname').value = '';
			$('syncterms').checked = false;
			$('sync-info').innerText = translate('Sign in to your Junecloud account to sync with any Mac, iPhone, iPad, iPod touch, or web browser. Data will be synced securely through junecloud.com.');
			selectTab('sync register');
		} else selectTab('sync signin');
	}

}

function saveSync () {

	if (!$('syncemail').value) {
		$('sync-info').innerText = translate('Please enter your email address.');
	} else if (!$('syncpassword').value) {
		$('sync-info').innerText = translate('Please enter your password.');
	} else if ($('cmd').value == 'register' && $('syncpassword').value != $('syncconfirm').value) {
		$('sync-info').innerText = translate('Both password fields must match.');
	} else if ($('cmd').value == 'register' && !$('syncterms').checked) {
		$('sync-info').innerText = translate('You must agree to the Terms of Service to continue.');
	} else {

		sync.email = $('syncemail').value;
		sync.password = true;
		syncQueue = [];

		widget.setPreferenceForKey(sync.email,'syncemail');
		Notefile.setPassword('junecloud.com',sync.email,$('syncpassword').value);

		var syncData = 'cmd='+$('cmd').value+'&type=widget&version='+syncVersion+'&osversion='+macOSVersion()+
			'&client='+encodeURIComponent(sync.client)+
			'&updated='+encodeURIComponent(sync.updated)+
			'&now='+encodeURIComponent(getUnixTime())+
			'&email='+encodeURIComponent($('syncemail').value);

		if ($('cmd').value == 'register') {

			sync.first = 1;
			syncData += '&newpassword='+encodeURIComponent($('syncpassword').value)+
				'&confirmpass='+encodeURIComponent($('syncconfirm').value)+
				'&name='+encodeURIComponent($('syncname').value);
			if ($('syncterms').checked) syncData += '&terms=1';

		} else {

			sync.first = 2;
			syncData += '&password='+encodeURIComponent($('syncpassword').value);

		}

		showMessage(translate('Syncing with Junecloud…'));
		$('sync-info').innerHTML = translate('Syncing with Junecloud…');
		sync.loadPage('https://junecloud.com/sync/notefile/xml.php',getSyncResult,syncData,false);

	}

}

function syncEnabled () {
	return (sync.email && sync.password) ? true : false;
}

function passwordOrCode () {
	return (sync.code) ? 'code='+encodeURIComponent(sync.code) : 
		'password='+encodeURIComponent(getPassword('junecloud.com',sync.email));
}

function timeForSync () {
	var result = false;
	if (syncEnabled()) {
		if (sync.force) {
			result = true;
			sync.force = false;
		} else if (sync.failures >= 5) {
			result = false;
		} else {
			var now = getUnixTime() - sync.offset;
			var inuse = activeUse();
			var syncInterval = (inuse) ? 300 : 1800;
			if (now > sync.updated + syncInterval) result = true;
		}
	}
	return result;
}

function syncNote (id,cmd,date) {
	if (syncEnabled()) {

		var modified = date;
		if (!modified && widget.preferenceForKey(id+'-modified')) modified = 
			parseFloat(widget.preferenceForKey(id+'-modified')) - sync.offset;

		var syncData = 'cmd='+cmd+'&type=widget&version='+syncVersion+'&osversion='+macOSVersion()+
			'&client='+encodeURIComponent(sync.client)+
			'&updated='+encodeURIComponent(sync.updated)+
			'&now='+encodeURIComponent(getUnixTime())+
			'&email='+encodeURIComponent(sync.email)+
			'&'+passwordOrCode()+
			'&uuid='+encodeURIComponent(id);
		if (modified) syncData += '&modified='+modified;

		if (cmd == 'add') syncData += '&text='+encodeURIComponent(widget.preferenceForKey(id+'-text'))+
			'&date='+encodeURIComponent(widget.preferenceForKey(id+'-date'));

		showMessage(translate('Syncing with Junecloud…'));
		$('sync-info').innerHTML = translate('Syncing with Junecloud…');

		var args = {method:'syncNote',cmd:cmd,id:id,date:modified};
		sync.loadPage('https://junecloud.com/sync/notefile/xml.php',getSyncResult,syncData,args);

	} else if (iCloudEnabled()) {

		var completeOutput = '';
		var thisCommand = widget.system('/usr/bin/osascript -e "return running of application \\\"Notefile\\\""',function(){

			var bundleID = (trim(completeOutput) === 'true') ? 'com.junecloud.mac.Notefile' : 'com.junecloud.Notefile-Helper';
			if (cmd == 'delete') {

				var thisCommand = widget.system("/usr/bin/osascript -e \"tell application id \\\""+bundleID+"\\\" to delete note \\\""+id+
					"\\\"\"",function(){});
				thisCommand.onreadoutput = continueSync;
				thisCommand.onreaderror = function(output){
					alert('Error saving to iCloud: '+output);
					queueNote(id,cmd,date);
				};

			} else {

				var thisText = appleScriptEscape(widget.preferenceForKey(id+'-text'));
				var thisDate = parseFloat(widget.preferenceForKey(id+'-date'));
				var thisCommand = widget.system("/usr/bin/osascript -e \"tell application id \\\""+bundleID+"\\\" to save note \\\""+id+
					"\\\" with text \\\""+thisText+"\\\" and date "+thisDate+"\"",function(){});
				thisCommand.onreadoutput = continueSync;
				thisCommand.onreaderror = function(output){
					alert('Error saving to iCloud: '+output);
					queueNote(id,cmd,date);
				};

			}

		});
		thisCommand.onreadoutput = function(thisOutput){
			completeOutput += thisOutput;
		};

	}
}

function appleScriptEscape (string) {
	if (typeof string != 'string') string = '';
	string = string.replace(/\\/g,'\\\\\\\\');
	string = string.replace(/\"/g,'\\\\\\"');
	string = string.replace(/\$/g,'\\$');
	string = string.replace(/\`/g,'\\`');
	return string.replace(/(\r\n|\r|\n)/g,'\n');
}

function queueNote (id,cmd,date) {
	var modified = date;
	if (!modified && widget.preferenceForKey(id+'-modified')) modified = 
		parseFloat(widget.preferenceForKey(id+'-modified')) - sync.offset;
	var item = {method:'syncNote',cmd:cmd,id:id,date:modified};
	syncQueue.push(item);
}

function addBackToQueue (item) {
	if (item) {
		for (i in syncQueue) {
			if (syncQueue[i].method == item.method && 
				syncQueue[i].id == item.id) {
				syncQueue.splice(i,1);
				break;	
			}
		}
		syncQueue.push(item);
	}
}

function removeFromQueue (id,olderThan) {
	for (var i in syncQueue) {
		if (syncQueue[i].id == id) {
			if (syncQueue[i].date < olderThan) {
				syncQueue.splice(i,1);
				return true;
			} else return false;
		}
	}
	return true;
}

function startSync () {

	var syncNow = false;
	var loggedIn = false;
	
	if (syncEnabled()) {
		if (syncQueue.length || timeForSync()) syncNow = true;
		loggedIn = true;
	}

	if (loggedIn) {

		if (syncNow) {
			if (!continueSync()) {
				var syncData = 'type=widget&version='+syncVersion+'&osversion='+macOSVersion();
				if (loggedIn) {
					syncData += '&cmd=get&client='+encodeURIComponent(sync.client)+
						'&updated='+encodeURIComponent(sync.updated)+
						'&now='+encodeURIComponent(getUnixTime())+
						'&email='+encodeURIComponent(sync.email)+
						'&'+passwordOrCode();
					showMessage(translate('Syncing with Junecloud…'));
					$('sync-info').innerHTML = translate('Syncing with Junecloud…');
				}
				sync.loadPage('https://junecloud.com/sync/notefile/xml.php',getSyncResult,syncData,false);
			}
		} else syncFinish();

	} else if (iCloudEnabled()) {

		var completeOutput = '';
		var thisCommand = widget.system('/usr/bin/osascript -e "return running of application \\\"Notefile\\\""',function(){
			if (trim(completeOutput) !== 'true') widget.system('/usr/bin/open -gb com.junecloud.Notefile-Helper',function(){});		
		});
		thisCommand.onreadoutput = function(thisOutput){
			completeOutput += thisOutput;
		};

		var iCloudData = Notefile.getiCloudFiles(iCloud.updated);
		if (iCloudData) {
			var iCloudFiles = JSON.parse(iCloudData);
			for (var x in iCloudFiles) {
	
				var file = iCloudFiles[x];
				if (file.archived) {
					deleteNoteWithId(file.uuid);
					if (file.uuid == currentNote) showList(false,false);
				} else {
					var modified = parseFloat(widget.preferenceForKey(file.uuid+'-modified'));
					if (isNaN(modified)) modified = 0;
					if (file.modified > modified) {
						if (window.widget) {
							widget.setPreferenceForKey(file.text,file.uuid+'-text');
							widget.setPreferenceForKey(file.date,file.uuid+'-date');
							widget.setPreferenceForKey(file.modified,file.uuid+'-modified');
						}
						updateList(file.uuid,true);
						if (file.uuid == currentNote && file.text != htmlToText($('content').innerHTML)) showNoteWithId(file.uuid);
					}
				}
				if (file.modified > iCloud.updated) iCloud.updated = file.modified;
	
			}
		}

		refreshList(true);
		updateStatus();

		var newUUID = Notefile.iCloudUUID();
		if (iCloud.uuid != newUUID) {

alert('iCloudUUID changed: '+iCloud.uuid+' to '+newUUID);

			iCloud.uuid = newUUID;
			widget.setPreferenceForKey(newUUID,'iclouduuid');
			syncQueue = [];
			var noteArray = getNoteArray();
			for (var i in noteArray) queueNote(noteArray[i],'add',0);
		}
		continueSync();

	}

}

function continueSync () {
	var willContinue = false;
	if (syncQueue.length) {
		var item = syncQueue.shift();
		if (item.method == 'syncNote') syncNote(item.id,item.cmd,item.date);
		willContinue = true;
	}
	return willContinue;
}

function searchArray (needle,haystack) {
	result = false;
	for (var i in haystack) {
		if (needle == haystack[i]) {
			result = true;
			break;
		}
	}
	return result;
}

function getSyncResult () {

	var success = false;
	var retry = false;

	if (this.status == 200 && this.responseXML) {
		for (var child = this.responseXML.firstChild; child != null; child = child.nextSibling) {
			if (child.nodeName == 'result') {
				var items = child;
				for (var item = items.firstChild; item != null; item = item.nextSibling) {

					if (item.nodeName == 'client') {

						sync.client = item.getAttribute('value');
						if (window.widget) widget.setPreferenceForKey(sync.client,widget.identifier+'-syncclient');

					} else if (item.nodeName == 'code') {

						sync.code = item.getAttribute('value');
						// Notefile.setPassword('junecloud.com',appId,sync.code);

					} else if (item.nodeName == 'message') {

						var message = translate(item.getAttribute('value'));
						if (message) showMessage(message);
						$('sync-info').innerHTML = message.replace(/…$/,'.').replace(/・・・$/,'');

					} else if (item.nodeName == 'success') {

						if (item.getAttribute('value') == 'true') {
							success = true;
						} else if (item.getAttribute('retry') == 'true') {
							retry = true;
						}

					} else if (item.nodeName == 'updated') {

						sync.updated = parseInt(item.getAttribute('value'),10);
						if (window.widget) widget.setPreferenceForKey(sync.updated,'syncupdated');

					} else if (item.nodeName == 'offset') {

						sync.offset = parseFloat(item.getAttribute('value'));
						if (window.widget) widget.setPreferenceForKey(sync.offset,'syncoffset');

					} else if (item.nodeName == 'note') {

						var id = (item.getAttribute('uuid')) ? item.getAttribute('uuid') : getUUID();
						var updated = (item.getAttribute('updated')) ? item.getAttribute('updated') : 0;

						if (removeFromQueue(id,updated)) {
							var deleted = (item.getAttribute('deleted') > 0) ? true : false;
							if (deleted) {
								deleteNoteWithId(id);
								if (id == currentNote) showList(false,false);
							} else if (item.firstChild) {
								var text = item.firstChild.data;
								if (window.widget) {
									widget.setPreferenceForKey(text,id+'-text');
									widget.setPreferenceForKey(item.getAttribute('date'),id+'-date');
									widget.setPreferenceForKey(getUnixTime(),id+'-modified');
								}
								updateList(id,true);
								if (id == currentNote && text != htmlToText($('content').innerHTML)) showNoteWithId(id);
							}

						}

					}
				}
				break;
			}
		}
		sync.failures = (!success && !retry) ? sync.failures + 1 : 0;

	} else {

		// If there's an error, output some helpful information to Console
		alert('Status: '+this.status+' '+navigator.userAgent);
		if (!this.responseXML) alert('No XML');
		var parser = new DOMParser();
		result = parser.parseFromString(this.responseText,'text/xml');
		if (result) {
			for (var child = result.firstChild; child != null; child = child.nextSibling) {
				for (var item = child.firstChild; item != null; item = item.nextSibling) {
					if (item.nodeName == 'parsererror') alert(item.innerText);
				}
			}
		}

	}

	sync.success = success;
	sync.retry = retry;
	refreshList(true);

	var willContinue = false;
	if (sync.success) {
		if (sync.first == 2) {				
			var noteArray = getNoteArray();
			for (var i in noteArray) queueNote(noteArray[i],'add',0);
		}
		if (currentSide == 'back' && currentView.split(' ')[0] == 'sync') setSync('login');
		sync.first = (sync.first == 1) ? 2 : 0;
		willContinue = continueSync();
	} else {
		if (this.args) addBackToQueue(this.args);
		if (!retry && !sync.code) {
			showInfo('sync signin');
			setSync('login');
		}
	}
	if (!willContinue) syncFinish();

}

function syncFail (item) {
	addBackToQueue(item);
	sync.success = false;
	syncFinish();
}

function syncFinish () {
	if (!sync.success && sync.retry) {
		// Notefile.deletePassword('junecloud.com',appId);
		sync.code = '';
		startSyncNow();
	} else {
		if (sync.success) forceJunecloud = false;
		updateStatus();
	}
	if (window.widget && typeof JSON == 'object') {
		if (syncQueue.length) {
			widget.setPreferenceForKey(JSON.stringify(syncQueue),'syncqueue');
		} else widget.setPreferenceForKey(null,'syncqueue');
	}
}

function logOut (tellServer) {
	// TODO: minor issue: sync client is added back when the server responds to the logout request.
	if (tellServer) {
		syncNote('','logout',0);
	} else $('sync-info').innerText = '';
	// Notefile.deletePassword('junecloud.com',appId);
	if (window.widget) {
		widget.setPreferenceForKey(null,'syncemail');
		widget.setPreferenceForKey(null,widget.identifier+'-syncclient');
		widget.setPreferenceForKey(null,'syncupdated');
		widget.setPreferenceForKey(null,'syncqueue');
	}
	sync.email = '';
	sync.password = false;
	sync.client = '';
	sync.code = '';
	sync.updated = 0;
	sync.success = false;
	sync.failures = 0;
	syncQueue = [];
	$('syncemail').value = '';
	$('syncpassword').value = '';
	setSync('login');
}


// ajax helper


function loadPage (url,method,postData,args) {

	var reqNo = this.reqCount;
	this.reqCount++;
	this.req[reqNo] = new XMLHttpRequest();
	this.req[reqNo].args = args;
	this.req[reqNo].onload = method;

	this.req[reqNo].onreadystatechange = function(){
		if (this.timer && this.readyState >= 3) clearTimeout(this.timer);
		if (this.readyState == 4 && this.status == 0 && !this.responseText) syncFail(args);
	}

	if (postData) {
		this.req[reqNo].open('POST',url);
		this.req[reqNo].setRequestHeader('Content-type','application/x-www-form-urlencoded');
		this.req[reqNo].setRequestHeader('Cache-Control','no-cache');
		this.req[reqNo].setRequestHeader('Content-length',postData.length);
		this.req[reqNo].setRequestHeader('Connection','close');
		this.req[reqNo].send(postData);
	} else {
		this.req[reqNo].open('GET',url);
		this.req[reqNo].setRequestHeader('Cache-Control','no-cache');
		this.req[reqNo].send();
	}

	var timeout = (sync.updated > 1) ? 30000 : 60000;
	this.req[reqNo].timer = setTimeout(function(){
		syncFail(args);
	},timeout);

}