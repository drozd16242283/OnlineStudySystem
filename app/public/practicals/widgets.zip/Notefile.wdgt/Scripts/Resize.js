var size = { width: 250, height: 285 };
var min  = { width: 200, height: 200 };
var max  = { width: 800, height: 800 };
var offset = { x: 0, y: 0 };
var maximized = false;

var snapDist = 0;
var scrollBar;
var scrollArea;
var scrollWidth = 0;
var nowAnimating = false;

function savedSize () {
	var width = 250;
	var height = 285;
	if (window.widget) {
		if (widget.preferenceForKey(widget.identifier+'-width')) width = widget.preferenceForKey(widget.identifier+'-width');
		if (widget.preferenceForKey(widget.identifier+'-height')) height = widget.preferenceForKey(widget.identifier+'-height');
	}
	return { width:width, height:height };
}

function setMinMax (view) {
	switch (view) {

		case 'note':
		case 'list':
			min.width  = 200;
			min.height  = 200;
			max.height = screen.height;
			break;

		case 'general':
		case 'donate':
			min.width  = 275;
			min.height = 250;
			max.height = screen.height;
			break;

		case 'sync icloud':
		case 'sync signin':
		case 'sync register':
		case 'sync signedin':
			min.width  = 275;
			var lang = translate('xx');
			// Use $('sync').scrollHeight?
			if (lang == 'de' || lang == 'en' || lang == 'sv') {
				min.height = (view == 'sync register') ? 410 : 330;
			} else min.height = (view == 'sync register') ? 430 : 370;
			max.height = screen.height;
			break;

	}
}

function startResize (e) {
	$('content').style.khtmlUserSelect = 'none';
	offset.x = window.innerWidth - e.pageX;
	offset.y = window.innerHeight - e.pageY;
	document.addEventListener('mousemove', doResize, true);
	document.addEventListener('mouseup', stopResize, true);
}

function stopResize () {
	$('content').style.khtmlUserSelect = 'text';
	document.removeEventListener('mousemove', doResize, true);
	document.removeEventListener('mouseup', stopResize, true); 
	saveSize(size);
}

function doResize (e) {
	var scrollbars = (currentSide == 'front') ? true : false;
	setSize(e.pageX+offset.x,e.pageY+offset.y,scrollbars,false);
	if (scrollbars) showScrollBar();
}

function setSize (width,height,scrollbars,animating) {
	var className = (textSize) ? 'textsize'+textSize : '';
	if (!animating) {
		if (height < min.height + snapDist) {
			height = min.height;
		} else if (height > max.height) {
			height = max.height;
		}
		var thisMin = (scrollbars && height < max.height) ? min.width + scrollWidth : min.width;
		if (width < thisMin + snapDist) {
			width = thisMin;
		} else if (width > max.width) {
			width = max.width;
		}
		// $('scrollbar').className = '';
	} else {
		// $('scrollbar').className = 'animating';
	}
	document.body.className = className;
	
	window.resizeTo(width,height);
	size.width = width;
	size.height = height;
	if (scrollArea) {
		if (!animating) scrollArea.refresh();
		updateDivider();
	}
}

function setMaximized (size) {
	maximized = (currentSide == 'front' && size.height >= max.height) ? true : false;
}

function saveSize (size) {
	if (window.widget) {
		widget.setPreferenceForKey(size.width,widget.identifier+'-width');
		widget.setPreferenceForKey(size.height,widget.identifier+'-height');
	}
	setMaximized(size);
}

function rectHandler (rectAnimation,currentRect,startingRect,finishingRect) {
	setSize(currentRect.right,currentRect.bottom,true,true);
}


// changing views


function switchToView (side,view) {
	if (nowAnimating) {
		// If the current transition isn't done, wait for it
		setTimeout(function(){switchToView(side,view)},1000);
	} else {
		nowAnimating = true;
		nextSide = side;
		nextView = view;
		setMinMax(nextView);
		if (currentSide == 'front') {
			scrollArea.blur();
			adjustSize();
		} else flipView();
	}
}

function adjustSize (forceExpand) {

	nowAnimating = true;
	var newSize = { width: size.width, height: size.height };
	if (currentSide != 'front') newSize = savedSize();

	if (min.width > newSize.width) {
		newSize.width = min.width;
	} else if (max.width < newSize.width) {
		newSize.width = max.width;
	}
	if (min.height > newSize.height) {
		newSize.height = min.height;
	} else if (max.height < newSize.height || forceExpand) {
		newSize.height = max.height;
	}
	if (forceExpand) saveSize(newSize);

	if (newSize.width != size.width || newSize.height != size.height) {
		var startingRect = new AppleRect(0,0,size.width,size.height);
		var finishingRect = new AppleRect(0,0,newSize.width,newSize.height);	
		var animation = new AppleRectAnimation(startingRect,finishingRect,rectHandler);
		var animator = new AppleAnimator(300,13);
		animator.addAnimation(animation);
		if (currentSide == 'front' && nextSide != 'front') {
			animator.oncomplete = flipView;
		} else animator.oncomplete = completeSwitch;
		animator.start();
	} else if (currentSide == 'front' && nextSide != 'front') {
		flipView();
	} else completeSwitch();

}

function flipView () {

	if (currentSide != nextSide) {
		var transition = (nextSide == 'front') ? 'ToFront' : 'ToBack';
		if (window.widget) widget.prepareForTransition(transition);
	}

	$(currentSide).style.display = 'none';
	$(nextSide).className = nextView;
	$(nextSide).style.display = 'block';

	setTimeout(function(){
			if (window.widget) widget.performTransition()
			if (currentSide == 'front' && nextSide != 'front') {
				completeSwitch();
			} else setTimeout(adjustSize,750);	
		},0);

}

function completeSwitch () {

	if (nextSide == 'front') {
		setSize(size.width,size.height,true,false);
		scrollArea.focus();
		updateStatus();
		showScrollBar();
	} else $(nextSide).className = nextView;

	currentSide = nextSide;
	currentView = nextView;

	if (!currentSide) {
		currentSide = 'front';
		currentView = 'note';
	}

	nowAnimating = false;

}

function refreshScrollArea () {
	scrollArea.refresh();
	updateDivider();
}

function updateDivider () {
	var opacity = 0;
	if (!scrollBar.hidden && $('scroll').scrollTop+$('scroll').offsetHeight < 
		$('scroll').scrollHeight) opacity = 1;
	$('divider').style.opacity = opacity;
}

function switchFront (view) {
	if (currentSide == 'front') {
		$('front').className = view;
		refreshScrollArea();
		scrollArea.verticalScrollTo(0);
		if (currentView != view) showScrollBar();
		currentView = view;
	}
}

function selectTab (tab) {
	if (currentView == 'general') saveSettings(false);
	setMinMax(tab);
	if (size.height < min.height) {
		nextSide = 'back';
		nextView = tab;
		adjustSize();
	} else {
		$('back').className = tab;
		// currentSide = 'back';
		currentView = tab;
	}
	if (tab.indexOf('sync') !== 0) forceJunecloud = false;
}