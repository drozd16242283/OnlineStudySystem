// Helper functions

function translate (key) {
	try {
		var ret = translation[key];
		if (ret === undefined || ret === '') ret = key;
		return ret;
	} catch (ex) { }
	return key;
}

function translateFormat (key,value1,value2,value3) {
	key = translate(key);
	if (value1) key = key.replace('%@',value1);
	if (value2) key = key.replace('%@',value2);
	if (value3) key = key.replace('%@',value3);
	return key;
}

function getUnixTime () {
	var currentTime = new Date();
	return currentTime.getTime()/1000;
}

// Display Text

function trim (string) {
	if (string) {
		// remove non-breaking space characters (&#160; or \xAO)
		while (string.indexOf(' ') > -1) {
			string = string.replace(' ',' ');
		}
		string = string.replace(/^(\s|&nbsp;)+|(\s|&nbsp;)+$/ig,'');
	}
	return string;
}

function htmlEntities (string) {
	if (string) {
		string = string.replace(/&/g,'&amp;');
		string = string.replace(/</g,'&lt;');
		string = string.replace(/>/g,'&gt;');
	}
	return string;
}

function removeHtmlEntities (string) {
	if (string) {
		string = string.replace(/\&lt;/g,'<');
		string = string.replace(/\&gt;/g,'>');
		string = string.replace(/&amp;/g,'&');
	}
	return string;
}

// WebKit Version Detection
// http://trac.webkit.org/projects/webkit/wiki/DetectingWebKit

function webKitVersion () {
    var webKitFields = RegExp("( AppleWebKit/)([^ ]+)").exec(navigator.userAgent);
    if (!webKitFields || webKitFields.length < 3) return null;
    var versionString = webKitFields[2];
    var isNightlyBuild = versionString.indexOf("+") != -1;
    var invalidCharacter = RegExp("[^\\.0-9]").exec(versionString);
    if (invalidCharacter) versionString = versionString.slice(0,invalidCharacter.index);
	// This will drop some numbers, but it's close enough. 530.19.2 becomes 530.19
    return parseFloat(versionString);
}

function macOSVersion () {
    var osXFields = RegExp("Mac OS X ([0-9_]+)").exec(navigator.userAgent);
    if (!osXFields || osXFields.length < 2) return '';
    return osXFields[1].split('_').join('.');
}