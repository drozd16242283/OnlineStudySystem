// French (Français) by Thierry Di Lenarda

var translation = [];
translation['xx'] = 'fr';

translation['Notefile requires OS X 10.5.8 or later and a Mac with an Intel processor.'] = 'Notefile nécessite Mac OS X 10.5.8 ou ultérieur.';

translation['No notes'] = 'Aucune note';
translation['1 note'] = '1 note';
translation['%@ notes'] = '%@ notes';

translation['No Results'] = 'Aucun résultat';

translation['today'] = 'aujourd’hui';
translation['tomorrow'] = 'demain';
translation['yesterday'] = 'hier';
translation['a moment ago'] = 'il y a un instant';
translation['a minute ago'] = 'il y a une minute';
translation['%@ minutes ago'] = 'il y a %@ minutes';
translation['an hour ago'] = 'il y a une heure';
translation['%@ hours ago'] = 'il y a %@ heures';
translation['a day ago'] = 'il y a un jour';
translation['%@ days ago'] = 'il y a %@ jours';

translation['Settings'] = 'Paramètres';
translation['Add'] = 'Ajouter';
translation['Delete'] = 'Supprimer';

translation['Syncing with iCloud…'] = 'Synchronisation avec iCloud…';
translation['Syncing with Junecloud…'] = 'Synchronisation avec Junecloud…';
translation['Couldn’t connect'] = 'Impossible de se connecter';
translation['Synced %@'] = 'Synchronisé %@';

translation['New version!'] = 'Nouvelle version!';
translation['A new version of Notefile is available! Click here to download it.'] = 'Une nouvelle version de Notefile est disponible! Cliquez ici pour la télécharger.';

translation['General'] = 'General';
translation['Sync'] = 'Synchro';
translation['Donate'] = 'Faire un don';
translation['Help'] = 'Aide';

translation['Sign In'] = 'Connexion';
translation['Register'] = 'S’inscrire';
translation['Done'] = 'Terminé';
translation['Log Out'] = 'Déconnexion';

translation['Text Size:'] = 'Taille du texte:';

translation['Donate'] = 'Faire un Don';
translation['Please consider a donation'] = 'Pensez à faire un don';
translation['This widget is free, but it took a lot of work to create it. Please consider a small donation to help support Notefile!'] = 'Le widget est gratuit, mais cela a demandé beaucoup de travail pour le développement. Merci de penser à une petite contribution pour aider au support de Notefile!';
translation['Check this box if you have donated.'] = 'Cochez cette case si vous avez déjà fait un don';
translation['Thank you for your donation! Your support allows us to keep making Notefile the best note keeping widget possible.'] = 'Merci pour votre contribution! Votre soutien nous permet de faire de Notefile le meilleur widget de gestion de notes possible.';

translation['Email Address:'] = 'Adresse email:';
translation['Password:'] = 'Mot de passe:';
translation['Confirm Password:'] = 'Confirmez le mot de passe:';
translation['Your Name:'] = 'Votre nom:';
translation['Optional'] = 'Optionnel';
translation['I agree to the <a href="http://junecloud.com/sync/legal/terms.html" onclick="return openSite(this.href)">Terms of Service</a>'] = 'J’accepte les <a href="http://junecloud.com/sync/legal/terms.html" onclick="return openSite(this.href)">Conditions d’Utilisation</a>';

translation['Syncing with iCloud'] = 'Vous synchronisez avec iCloud';
translation['Syncing with Junecloud'] = 'Vous synchronisez avec Junecloud';
translation['Switch to iCloud'] = 'Changer vers iCloud';
translation['Switch to Junecloud'] = 'Changer vers Junecloud';
translation['If you need to change your settings, open System Preferences and click iCloud.'] = 'Si vous devez changer vos paramètres, ouvrez Préférences Système puis cliquez sur iCloud.';
translation['Sign in to your Junecloud account to sync with any Mac, iPhone, iPad, iPod touch, or web browser. Data will be synced securely through junecloud.com.'] = 'Connectez-vous à votre compte Junecloud pour synchroniser n’importe quel Mac, iPhone, iPad, iPod touch ou navigateur Web. Les données seront synchronisées de manière sécurisée via junecloud.com.';
translation['You are currently signed in as %@'] = 'Vous êtes connecté sous %@';
translation['Forgot your password?'] = 'Mot de passe oublié?';
translation['Log in successful.'] = 'Connexion réussie.';
translation['You have been logged out.'] = 'Vous êtes déconnecté.';

translation['Please enter your email address.'] = 'Veuillez entrer votre adresse e-mail.';
translation['Please enter your password.'] = 'Veuillez entrer votre mot de passe.';
translation['Both password fields must match.'] = 'Les champs de mot de passe doivent être identiques.';
translation['Your email address or password is incorrect.'] = 'Votre adresse email ou mot de passe est incorrect.';
translation['You must agree to the Terms of Service to continue.'] = 'Vous devez accepter les conditions d’utilisation du service pour continuer.';